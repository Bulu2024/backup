#!/bin/bash

source "$ENV_PATH"

# --- Configuration ---
TTL_FILE="$MAIN_DIR/conf/$1"
JOB="[TTL_APPLIER]"  # Job identifier
CLICKHOUSE_USER="default"
CLICKHOUSE_PASSWORD="dbadmin"
CLICKHOUSE_DB="default"
CLUSTER_NAME="cluster_analytics"  # update if needed

# --- Logging Function ---
log() {
  local timestamp
  timestamp=$(date +"%Y-%m-%d %H:%M:%S")
  echo "$timestamp $JOB: $*" | tee -a "$LOG_FILE"
}

log "Starting TTL application process..."

# Check if the file exists
if [ ! -f "$TTL_FILE" ]; then
  log "Error: TTL file not found at: $TTL_FILE"
  exit 1
fi

while IFS=, read -r table ttl ttl_col; do
  # Trim whitespace (spaces, tabs, etc.) from all fields
  table=$(echo "$table" | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
  ttl=$(echo "$ttl" | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
  ttl_col=$(echo "$ttl_col" | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
  
  # Skip empty lines or lines where any field is missing, and ignore comments
  if [[ -z "$table" ]] || [[ -z "$ttl" ]] || [[ -z "$ttl_col" ]] || [[ "$table" == \#* ]]; then
      continue
  fi

  # Construct the ALTER TABLE query using the provided start_time column
  query="ALTER TABLE ${table} ON CLUSTER ${CLUSTER_NAME} MODIFY TTL ${ttl_col} + INTERVAL ${ttl} DELETE;"
  log "Executing: $query"

  # Execute the command with clickhouse-client
  clickhouse-client \
    --user "$CLICKHOUSE_USER" \
    --password "$CLICKHOUSE_PASSWORD" \
    --database "$CLICKHOUSE_DB" \
    --query "$query" 2>&1 >/dev/null

  if [ $? -eq 0 ]; then
    log "  Success."
  else
    log "  Error executing command: $query"
    # Uncomment for more detailed output:
    # log "   Output: $(clickhouse-client --user "$CLICKHOUSE_USER" --password "$CLICKHOUSE_PASSWORD" --database "$CLICKHOUSE_DB" --query "$query" 2>&1)"
  fi

done < "$TTL_FILE"

log "TTL application process finished."

exit 0

