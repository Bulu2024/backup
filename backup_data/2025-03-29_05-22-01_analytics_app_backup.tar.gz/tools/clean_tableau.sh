#!/bin/bash

tsm cache clean

# Removes old logs, temp, and cache files.
tsm maintenance cleanup -r

tsm maintenance cleanup -l

tsm maintenance cleanup -p
