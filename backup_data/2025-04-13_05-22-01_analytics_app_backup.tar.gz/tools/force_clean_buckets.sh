#!/bin/bash

source $ENV_PATH

rm $CONNDR_DIR/1_received/* -rf
rm $CONNDR_DIR/2_processing/* -rf
rm $CONNDR_DIR/3_done/* -rf
rm $CONNDR_DIR/4_error/* -rf

rm $CONV_DIR/1_received/* -rf
rm $CONV_DIR/2_processing/* -rf
rm $CONV_DIR/3_done/* -rf
rm $CONV_DIR/4_error/* -rf

rm $ULI_DIR/1_received/* -rf
rm $ULI_DIR/2_processing/* -rf
rm $ULI_DIR/3_done/* -rf
rm $ULI_DIR/4_error/* -rf

rm $HDR_DIR/1_received/* -rf
rm $HDR_DIR/2_processing/* -rf
rm $HDR_DIR/3_done/* -rf
rm $HDR_DIR/4_error/* -rf

rm $SDR_DIR/1_received/* -rf
rm $SDR_DIR/2_processing/* -rf
rm $SDR_DIR/3_done/* -rf
rm $SDR_DIR/4_error/* -rf


echo "All buckets files removed"
