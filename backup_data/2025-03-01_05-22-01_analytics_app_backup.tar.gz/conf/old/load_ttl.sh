#!/bin/bash

source $ENV_PATH

# --- Configuration ---
TTL_FILE="$MAIN_DIR/conf/$1"
JOB="[TTL_APPLIER]"  # Job identifier
CLICKHOUSE_USER="default"
CLICKHOUSE_PASSWORD="dbadmin"
CLICKHOUSE_DB="default"

# --- Logging Function ---
log() {
  local timestamp=$(date +"%Y-%m-%d %H:%M:%S")
  echo "$timestamp $JOB: $*" | tee -a "$LOG_FILE"
}

# --- Main Script ---

log "Starting TTL application process..."

# Check if the file exists
if [ ! -f "$TTL_FILE" ]; then
  log "Error: TTL file not found at: $TTL_FILE"
  exit 1
fi

while IFS= read -r line; do
  # Remove leading/trailing whitespace
  line=$(echo "$line" | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')

  # Skip empty lines and comments
  if [[ -z "$line" ]] || [[ "$line" == \#* ]]; then
      continue
  fi

  log "Executing: $line"
  
  # Execute the command with clickhouse-client
  clickhouse-client \
    --user "$CLICKHOUSE_USER" \
    --password "$CLICKHOUSE_PASSWORD" \
    --database "$CLICKHOUSE_DB" \
    --query "$line" 2>&1 >/dev/null
    
    
  if [ $? -eq 0 ]; then
    log "  Success."
  else
    log "  Error executing command: $line"
    # If you need more info, uncomment next line to print command output
    #log "   Output: $(clickhouse-client --user "$CLICKHOUSE_USER" --password "$CLICKHOUSE_PASSWORD" --database "$CLICKHOUSE_DB" --query "$line" 2>&1)"
  fi


done < "$TTL_FILE"


log "TTL application process finished."

exit 0
