#!/usr/bin/env python3

import csv
from prettytable import PrettyTable
import sys

def print_csv_as_table(file_path):
    # Initialize PrettyTable
    table = PrettyTable()

    try:
        # Open the CSV file and read its content
        with open(file_path, newline='', encoding='utf-8') as csvfile:
            reader = csv.reader(csvfile)

            # Extract header and rows
            headers = next(reader)  # First row is the header
            table.field_names = headers  # Set table headers

            # Add rows to the table
            for row in reader:
                table.add_row(row)

        # Print the table
        print(table)

    except FileNotFoundError:
        print(f"Error: File '{file_path}' not found.")
        sys.exit(1)
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: ./print_table.py <csv_file>")
        sys.exit(1)
    
    file_path = sys.argv[1]  # Get the file path from the first argument
    print_csv_as_table(file_path)

