#!/bin/bash

source $ENV_PATH

TABLENAME=$1
FILECSV=$2

clickhouse-client --host=$DB_IP --database=$DB_NAME --user=$DB_USER --password=$DB_PASSWORD --query="INSERT INTO default.$TABLENAME FORMAT CSVWithNames" < $FILECSV
