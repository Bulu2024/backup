#!/bin/bash

source $ENV_PATH

rm $CONNDR_DIR/1_received/* -rf
rm $CONNDR_DIR/2_processing/* -rf
rm $CONNDR_DIR/3_done/* -rf
rm $CONNDR_DIR/4_error/* -rf

rm $CONV_DIR/1_received/* -rf
rm $CONV_DIR/2_processing/* -rf
rm $CONV_DIR/3_done/* -rf
rm $CONV_DIR/4_error/* -rf

echo "All buckets files removed"
