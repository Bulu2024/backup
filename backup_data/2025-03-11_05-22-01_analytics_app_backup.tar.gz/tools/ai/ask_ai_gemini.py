#!/usr/bin/env python3.6
import os
import requests
import json
import logging
from dotenv import load_dotenv
from clickhouse_driver import Client
from datetime import datetime, timedelta

# Load environment variables from the specified path
DEFAULT_ENV_PATH = os.getenv('ENV_PATH')
if os.path.exists(DEFAULT_ENV_PATH):
    load_dotenv(dotenv_path=DEFAULT_ENV_PATH)
else:
    print(f"ERROR: No env file found at {ENV_PATH} or {DEFAULT_ENV_PATH}!")
    exit()


GOOGLE_API_KEY = os.getenv('GOOGLE_API_KEY')
LOG_FILE = os.getenv('LOG_FILE')
DB_IP = os.getenv('DB_IP')
DB_USER = os.getenv('DB_USER')
DB_PASSWORD = os.getenv('DB_PASSWORD')
DB_NAME = os.getenv('DB_NAME')

JOB_NAME = "GEMINI_CLICKHOUSE_INTEGRATION"
logging.basicConfig(filename=LOG_FILE, level=logging.INFO,
                    format='%(asctime)s.%(msecs)03d [' + JOB_NAME + '] %(message)s',
                    datefmt='%Y-%m-%d %H:%M:%S')


def generate_text_gemini(prompt):
    url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent"
    # url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-pro-flash:generateContent"
    # url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2-pro-001:generateContent"

    headers = {
        "Content-Type": "application/json",
    }
    params = {
        "key": GOOGLE_API_KEY
    }
    data = {
      "contents": [{
        "parts":[{
            "text": prompt
        }]
      }]
    }
    response = requests.post(url, headers=headers, params=params, data=json.dumps(data))
    response.raise_for_status()
    response_data = response.json()
    try:
       text_output = response_data['candidates'][0]['content']['parts'][0]['text']
    except Exception as e:
       logging.error(f"Error getting output: {e}")
       text_output = ""
    print(f"DEBUG: Gemini API output: {text_output}") # Debug print
    return text_output


def get_clickhouse_client():
    """Establishes a connection to ClickHouse using environment variables."""
    client = Client(
        host=DB_IP,
        user=DB_USER,
        password=DB_PASSWORD,
        database=DB_NAME) #Include DB_NAME to the connection
    client.execute("SELECT 1")
    logging.debug("Successfully connected to ClickHouse")
    return client


def execute_clickhouse_query(sql_query):
    """Executes a SQL query against ClickHouse and returns the results."""
    client = get_clickhouse_client()
    try:
        results = client.execute(sql_query)
        logging.debug(f"SQL Query Executed Successfully: {sql_query}")
        print(f"DEBUG: ClickHouse query results: {results}")  # Debug print
        return results
    except Exception as e:
        logging.error(f"Error executing ClickHouse query: {e}")
        return None


def format_clickhouse_results(results):
    """Formats ClickHouse results into a string."""
    if not results:
        print("DEBUG: No results to format.") # Debug print
        return "No results found."
    formatted_output = ""
    for row in results:
        formatted_output += str(row) + "\n"
    print(f"DEBUG: Formatted output: {formatted_output}") # Debug print
    return formatted_output


def generate_sql_query(internal_instructions, user_question):
    """Generates SQL query using Gemini"""
    prompt = f"""
        You are a SQL query generator.
        General instructions:
        {internal_instructions}
        And the user question:
        {user_question}
        Generate the query, return query output or nothing.
    """

    sql_query = generate_text_gemini(prompt)
    logging.debug(f"Generated SQL Query: {sql_query}")

    if sql_query.lower().startswith("error"):
         return None
    else:
         return sql_query

def generate_answer(formatted_output, user_question):
   """Generates an answer to the user question using the DB results"""
   prompt = f"""
        Based on the following DB output:
        {formatted_output}
        
        and this question:
        {user_question}

        generate a human friendly answer. 
    """
   answer = generate_text_gemini(prompt)
   logging.debug(f"Generated Answer: {answer}")
   print(f"DEBUG: Final answer from Gemini: {answer}") # Debug print
   return answer


if __name__ == "__main__":
    # --- Internal instructions about the DB (this will be in the code/config) ---
    internal_instructions = """
    Clickhouse Table name: fact_agg_hour (has records for the last 30 Days)
    subscriber_key,String # MSISDN of the subscriber
    start_time_1hour,DateTime # end time of the connection YYYY-MM-DD HH:MM:SS
    int_ipv4,IPv4 # Internal IP
    app_key,String # This is the name of the application, i.e. "Facebook", "WhatsApp", "WhatsApp Calls", etc.
    uli,String	# This is cell-ID (base-station) which can indicate the location of the subscriber
    volume_in,UInt64
    volume_out,UInt64

    Instructions:
    1. Timeformat: YYYY-MM-DD HH:MM:SS (always fill in the full date+time)
    2. Know which table to ask (note its better to use fact_rt - more accurate, but if you asked for details beyond the aging, use fact_agg_hour
    """
    # --- Example user question ---
    user_question = "give me the top 5 subscribers that used Uber between 2025-01-10 to 2025-01-13"

    # --- Process ---
    sql_query = generate_sql_query(internal_instructions, user_question)
    # print(f"DEBUG: Generated SQL Query: {sql_query}") # Debug print

    if sql_query:
       results = execute_clickhouse_query(sql_query)
       formatted_output = format_clickhouse_results(results)
       answer = generate_answer(formatted_output, user_question)
       print(answer)
    else:
       print("Error: Could not generate SQL query, please check the logs for more details.")