#!/bin/bash

# Load environment variables
if [ -z "$ENV_PATH" ]; then
  echo "Error: ENV_PATH environment variable is not set."
  exit 1
fi

source "$ENV_PATH"

# Check if the table name argument is provided
if [ -z "$1" ]; then
  echo "Usage: $0 <table_name>"
  exit 1
fi

TABLE_NAME="$1"
JOB="[TABLE_COPY]"

# Ensure the log file exists
touch "$LOG_FILE"
chmod 666 "$LOG_FILE"

echo "$(date "+%Y-%m-%d %H:%M:%S.%3N") $JOB Starting copy for table '$TABLE_NAME'" >> "$LOG_FILE"

# Construct the connection strings for each DWH node
DWH1_CONN="clickhouse-client --host $DWH1 --user $DB_USER --password $DB_PASSWORD --database $DB_NAME"
DWH2_CONN="clickhouse-client --host $DWH2 --user $DB_USER --password $DB_PASSWORD --database $DB_NAME"
DWH3_CONN="clickhouse-client --host $DWH3 --user $DB_USER --password $DB_PASSWORD --database $DB_NAME"

###################################################################
# 1. Truncate data on DWH2
###################################################################
echo "$(date "+%Y-%m-%d %H:%M:%S.%3N") $JOB Truncating table '$TABLE_NAME' on DWH2." >> "$LOG_FILE"

$DWH2_CONN --query "TRUNCATE TABLE ${TABLE_NAME}"
if [ $? -ne 0 ]; then
  echo "$(date "+%Y-%m-%d %H:%M:%S.%3N") $JOB ERROR: Failed to truncate table on DWH2. Check ClickHouse logs." >> "$LOG_FILE"
  exit 1
fi

###################################################################
# 2. Truncate data on DWH3
###################################################################
echo "$(date "+%Y-%m-%d %H:%M:%S.%3N") $JOB Truncating table '$TABLE_NAME' on DWH3." >> "$LOG_FILE"

$DWH3_CONN --query "TRUNCATE TABLE ${TABLE_NAME}"
if [ $? -ne 0 ]; then
  echo "$(date "+%Y-%m-%d %H:%M:%S.%3N") $JOB ERROR: Failed to truncate table on DWH3. Check ClickHouse logs." >> "$LOG_FILE"
  exit 1
fi

###################################################################
# 3. Push aggregator states from DWH1 to DWH2
###################################################################
echo "$(date "+%Y-%m-%d %H:%M:%S.%3N") $JOB Pushing data from DWH1 to DWH2 for '$TABLE_NAME'." >> "$LOG_FILE"

$DWH1_CONN --query "
INSERT INTO TABLE FUNCTION remote('$DWH2:9000','${DB_NAME}','${TABLE_NAME}','${DB_USER}','${DB_PASSWORD}')
SELECT *
FROM ${TABLE_NAME};
"

if [ $? -ne 0 ]; then
  echo "$(date "+%Y-%m-%d %H:%M:%S.%3N") $JOB ERROR: Failed to push data from DWH1 to DWH2. Check ClickHouse logs." >> "$LOG_FILE"
  exit 1
fi

###################################################################
# 4. Push aggregator states from DWH1 to DWH3
###################################################################
echo "$(date "+%Y-%m-%d %H:%M:%S.%3N") $JOB Pushing data from DWH1 to DWH3 for '$TABLE_NAME'." >> "$LOG_FILE"

$DWH1_CONN --query "
INSERT INTO TABLE FUNCTION remote('$DWH3:9000','${DB_NAME}','${TABLE_NAME}','${DB_USER}','${DB_PASSWORD}')
SELECT *
FROM ${TABLE_NAME};
"

if [ $? -ne 0 ]; then
  echo "$(date "+%Y-%m-%d %H:%M:%S.%3N") $JOB ERROR: Failed to push data from DWH1 to DWH3. Check ClickHouse logs." >> "$LOG_FILE"
  exit 1
fi

###################################################################
# 5. Optimize on all nodes (optional, especially for AggregatingMergeTree)
###################################################################
echo "$(date "+%Y-%m-%d %H:%M:%S.%3N") $JOB Running OPTIMIZE FINAL on all nodes for '$TABLE_NAME'." >> "$LOG_FILE"

$DWH1_CONN --query "OPTIMIZE TABLE ${TABLE_NAME} FINAL"
$DWH2_CONN --query "OPTIMIZE TABLE ${TABLE_NAME} FINAL"
$DWH3_CONN --query "OPTIMIZE TABLE ${TABLE_NAME} FINAL"

echo "$(date "+%Y-%m-%d %H:%M:%S.%3N") $JOB Completed data copy and optimize for table '$TABLE_NAME'." >> "$LOG_FILE"

exit 0

