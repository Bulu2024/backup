#!/bin/bash

SRC_DIR="/analytics/conndr_input/1_received"
DST_DIR="/analytics/conndr_input/2_modified"
DONE_DIR="/analytics/conndr_input/3_done"
LOG_FILE="/analytics/main.log"
JOB="[BUCKETS_MODIFIER]"

# Ensure the processed directory exists
mkdir -p "$DST_DIR"

# Ensure the log file exists
touch "$LOG_FILE"
chmod 666 "$LOG_FILE"

# Desired column names
COLUMN_NAMES="subscriber_key,start_time,end_time,int_ipv4,ext_ipv4,app_key,uli,request_host,volume_in,volume_out,allot_subscriber,conndr_record_type,IMEITAC,IMSI,IMEISV,sg_name,int_port,ext_port,l5_protocol,request_uri,packets_in,packets_out,IMSI_MCC_MNC"

# Get timezone offset in hours (first two characters)
DELTA=$(date +%z)
DELTA_HOURS=${DELTA:0:3}  # Get the first 3 characters (e.g., +02 or -03)

# Loop through all .csv.gz files in the source directory
for file in "$SRC_DIR"/*.csv.gz; do
    # Skip if no files found
    if [[ ! -f "$file" ]]; then
        break
    fi

    echo "$(date "+%Y-%m-%d %H:%M:%S.%3N") $JOB start $(basename "${file%.gz}" .csv).csv.gz." >> "$LOG_FILE"

    # Extract the file
    gzip -dc "$file" > "${file%.gz}"

    # Initialize record counter
    record_count=0

    # Transform the datetime fields and replace the header
    awk -F',' -v OFS=',' -v DELTA_HOURS="$DELTA_HOURS" -v HEADER="$COLUMN_NAMES" '
    BEGIN {
        header_printed = 0
    }
    NR == 1 {
        # Replace the first line with the custom column names
        print HEADER
        header_printed = 1
        next
    }
    {
        # Remove quotes and "GMT" from StartTime and EndTime
        gsub(/\"/, "", $2); gsub(/\"/, "", $3); sub(/ GMT$/, "", $2); sub(/ GMT$/, "", $3)

        # Convert StartTime and EndTime to epoch, adjust with delta, and format as local time
        start_time = $2
        end_time = $3
        
        # Convert to epoch (UTC) and adjust by DELTA_HOURS
        start_epoch = mktime(substr(start_time, 1, 4) " " substr(start_time, 6, 2) " " substr(start_time, 9, 2) " " substr(start_time, 12, 2) " " substr(start_time, 15, 2) " " substr(start_time, 18, 2))
        end_epoch = mktime(substr(end_time, 1, 4) " " substr(end_time, 6, 2) " " substr(end_time, 9, 2) " " substr(end_time, 12, 2) " " substr(end_time, 15, 2) " " substr(end_time, 18, 2))

        # Adjust by the timezone delta in hours
        start_epoch += DELTA_HOURS * 3600
        end_epoch += DELTA_HOURS * 3600

        # Convert back to the desired date format
        $2 = strftime("%Y-%m-%d %H:%M:%S", start_epoch)
        $3 = strftime("%Y-%m-%d %H:%M:%S", end_epoch)

        print $0
    }' "${file%.gz}" > "$DST_DIR/$(basename "${file%.gz}" .csv).modified.csv"

    # Count lines while processing
    while IFS= read -r line; do
        record_count=$((record_count + 1))
    done < "${file%.gz}"

    # Compress the modified file
    gzip "$DST_DIR/$(basename "${file%.gz}" .csv).modified.csv"

    echo "$(date "+%Y-%m-%d %H:%M:%S.%3N") $JOB $record_count records $(basename "${file%.gz}" .csv).modified.csv.gz" >> "$LOG_FILE"

    mv "$file" "$DONE_DIR"

    rm -f "${file%.gz}"
done
