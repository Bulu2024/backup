#!/usr/bin/env python3.6

import datetime
import os
import shutil
import gzip
import logging
from dotenv import load_dotenv


DEFAULT_ENV_PATH = os.getenv('ENV_PATH')
if os.path.exists(DEFAULT_ENV_PATH):
    load_dotenv(dotenv_path=DEFAULT_ENV_PATH)
else:
    print(f"ERROR: No env file found at {ENV_PATH} or {DEFAULT_ENV_PATH}!")
    exit()

MAIN_DIR = os.getenv('MAIN_DIR')  # Default if not in env
CONNDR_DIR = os.getenv('CONNDR_DIR') #Default if not in env

# --- Configuration ---
INPUT_DIR = os.path.join(MAIN_DIR, "tools/background")
WORKING_DIR = os.path.join(MAIN_DIR, "tools/background/working")
OUTPUT_DIR = os.path.join(CONNDR_DIR, "1_received")
FILE_PREFIX = "conndr_input_5min_"
FILE_EXTENSION = ".csv"
DATE_FORMAT_IN_FILE = "YYYY-MM-DD"
DATE_FORMAT_OUT_FILE = "%Y-%m-%d"
LOG_FILE = os.path.join(MAIN_DIR, "tools/background/generate_background_conndr.log")

# Configure logging
logging.basicConfig(filename=LOG_FILE, level=logging.INFO, format='%(asctime)s - %(message)s')

def get_rounded_time_filename():
    """Calculates the nearest rounded 5-minute timestamp and returns the corresponding filename."""
    now = datetime.datetime.now()
    minutes = now.minute
    rounded_minutes = (minutes // 5) * 5
    rounded_time = now.replace(minute=rounded_minutes, second=0, microsecond=0)
    return rounded_time.strftime("%H:%M:%S")


def create_dated_file(source_file, dest_dir, rounded_time, date_str):
    """
    Copies the content of the source file to a new file with the current date.
    Replaces date placeholders in the content.

    Args:
        source_file (str): Path to the source file.
        dest_dir (str): Destination directory.
        rounded_time (str): Time of the file (HH:MM:SS) as string, needed for file name.
        date_str (str): Current date as string (YYYY-MM-DD).
    """
    dest_file = os.path.join(dest_dir, f"{FILE_PREFIX}{date_str}_{rounded_time}{FILE_EXTENSION}")

    with open(source_file, 'r') as infile, open(dest_file, 'w') as outfile:
        for line in infile:
            outfile.write(line.replace(DATE_FORMAT_IN_FILE, date_str))
    return dest_file


def gzip_file(filepath):
    """Gzips a file and returns the path to the gzipped file."""
    gzipped_filepath = filepath + ".gz"
    with open(filepath, 'rb') as f_in, gzip.open(gzipped_filepath, 'wb') as f_out:
        shutil.copyfileobj(f_in, f_out)
    return gzipped_filepath

def main():
    """Main function to execute the file processing."""
    start_time = datetime.datetime.now()

    rounded_time = get_rounded_time_filename()
    current_date = datetime.datetime.now().strftime(DATE_FORMAT_OUT_FILE)
    source_filename = f"{FILE_PREFIX}{rounded_time}{FILE_EXTENSION}"
    source_file = os.path.join(INPUT_DIR, source_filename)

    if not os.path.exists(source_file):
        logging.error(f"Error: Source file not found: {source_file}")
        logging.info(f"Start: {start_time}, End: {datetime.datetime.now()}, File loaded: False, Rows added: 0")
        return

    # Ensure destination directories exists
    os.makedirs(WORKING_DIR, exist_ok=True)
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    try:
        dated_file = create_dated_file(source_file, WORKING_DIR, rounded_time, current_date)
        gzipped_file = gzip_file(dated_file)

        # Move the gzipped file to the output directory
        shutil.move(gzipped_file, OUTPUT_DIR)
        
        # Optionally, remove the uncompressed file from working dir after processing
        os.remove(dated_file)

        num_rows = sum(1 for line in open(source_file))
        logging.info(f"Start: {start_time}, End: {datetime.datetime.now()}, File loaded: {source_file}, Rows added: {num_rows}")


    except Exception as e:
        logging.error(f"Error processing file: {e}")
        logging.info(f"Start: {start_time}, End: {datetime.datetime.now()}, File loaded: False, Rows added: 0")



if __name__ == "__main__":
    main()