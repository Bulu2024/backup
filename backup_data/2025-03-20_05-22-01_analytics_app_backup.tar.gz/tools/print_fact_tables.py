#!/usr/bin/env python3
import os
import re
from dotenv import load_dotenv
from clickhouse_driver import Client

DEFAULT_ENV_PATH = os.getenv('ENV_PATH')
if os.path.exists(DEFAULT_ENV_PATH):
    load_dotenv(dotenv_path=DEFAULT_ENV_PATH)
else:
    print(f"ERROR: No env file found at {DEFAULT_ENV_PATH}!")
    exit()

DB_IP = os.getenv('DB_IP')
DB_USER = os.getenv('DB_USER')
DB_PASSWORD = os.getenv('DB_PASSWORD')
DB_NAME = os.getenv('DB_NAME')

def get_clickhouse_client():
    client = Client(
        host=DB_IP,
        user=DB_USER,
        password=DB_PASSWORD,
        database=DB_NAME
    )
    client.execute("SELECT 1")
    return client

client = get_clickhouse_client()

# Get all tables matching fact_%
tables = client.execute("""
    SELECT name FROM system.tables
    WHERE database = currentDatabase() AND name LIKE 'fact_%'
""")

results = []

for (table_name,) in tables:
    # Run SHOW CREATE TABLE to get full DDL
    create_query = client.execute("SHOW CREATE TABLE {}".format(table_name))[0][0]

    # Extract the PARTITION BY clause from the DDL.
    m = re.search(r"PARTITION BY\s+([^\n]+)", create_query)
    partition_by = m.group(1).strip() if m else "N/A"

    # Extract the TTL clause from the DDL.
    m_ttl = re.search(r"TTL\s+([^\n]+)", create_query)
    ttl_clause = m_ttl.group(1).strip() if m_ttl else "N/A"
    
    # Extract the ORDER BY clause from the DDL.
    m_order = re.search(r"ORDER BY\s+([^\n]+)", create_query)
    order_by_clause = m_order.group(1).strip() if m_order else "N/A"

    # Get record count from system.parts (summing rows in active parts)
    rec = client.execute("""
        SELECT sum(rows) FROM system.parts
        WHERE database = currentDatabase() AND table = %(table)s AND active = 1
    """, {"table": table_name})
    records = rec[0][0] if rec[0][0] is not None else 0

    results.append((table_name, partition_by, records, ttl_clause, order_by_clause))

# Sort results by the number of records in descending order
results.sort(key=lambda x: x[2], reverse=True)

# Define column widths
col1_width = 30  # Table Name
col2_width = 30  # Partition By (reduced)
col3_width = 20  # Records
col4_width = 40  # TTL
col5_width = 30  # Order By (more delimited space)

header = "{:<{w1}} {:<{w2}} {:>{w3}} {:<{w4}} {:<{w5}}".format(
    "Table Name", "Partition By", "Records", "TTL", "Order By",
    w1=col1_width, w2=col2_width, w3=col3_width, w4=col4_width, w5=col5_width
)
print(header)
print("-" * (col1_width + col2_width + col3_width + col4_width + col5_width + 4))

for table_name, partition_by, records, ttl_clause, order_by_clause in results:
    print("{:<{w1}} {:<{w2}} {:>{w3},} {:<{w4}} {:<{w5}}".format(
        table_name, partition_by, records, ttl_clause, order_by_clause,
        w1=col1_width, w2=col2_width, w3=col3_width, w4=col4_width, w5=col5_width
    ))

