#!/usr/bin/env python3.6
import csv
import random
from datetime import datetime, timedelta

def get_uli_suffix(timestamp_str, uli_table):
    """
    Matches the timestamp with a 5-minute interval in the uli table and returns the corresponding suffix.

    Args:
        timestamp_str: String representation of the timestamp (e.g., "2025-01-04 00:05:00").
        uli_table: Dictionary mapping timestamps to ULI suffixes.

    Returns:
        The ULI suffix or None if no match is found.
    """
    try:
        timestamp = datetime.strptime(timestamp_str, "%Y-%m-%d %H:%M:%S")
    except ValueError as e:
        print(f"Error parsing timestamp: {timestamp_str}. Error: {e}")
        return None
        
    for table_time_str, suffix in uli_table.items():
        table_time = datetime.strptime(table_time_str, "%H:%M")
        table_time_with_date = timestamp.replace(hour=table_time.hour, minute=table_time.minute, second=0)
        if abs((timestamp - table_time_with_date).total_seconds()) <= 150:  # Check within 5 min 
            return suffix
    return None


def generate_random_uli():
    """Generates a random ULI number between the specified range."""
    return random.randint(17922520000001, 17922520000300)


def process_csv(input_file, output_file, uli_table, mod=10):
    """
    Reads a CSV file, modifies the ULI field based on subscriber_key and time, and writes to a new CSV.

    Args:
        input_file: Path to the input CSV file.
        output_file: Path to the output CSV file.
        uli_table: Dictionary mapping timestamps to ULI suffixes.
        mod: divisor to determine which subsribers uli are modified based on a lookup table (every 10th)
    """
    with open(input_file, 'r', newline='') as infile, \
            open(output_file, 'w', newline='') as outfile:
        reader = csv.reader(infile)
        writer = csv.writer(outfile)

        header = next(reader)
        writer.writerow(header)  # Write the header to the output file

        for row in reader:
            try:
                subscriber_key = int(row[0])
                start_time = row[1] # format: 2025-01-04 00:00:00

                if subscriber_key % mod == 0:
                    uli_suffix = get_uli_suffix(start_time, uli_table)
                    
                    if uli_suffix:
                        uli = 17922520000000 + int(uli_suffix)
                        row[6] = uli #replace the uli number
                    else:
                         row[6] = generate_random_uli() #replace the uli number with random if no match in the lookup table
                else:
                    row[6] = generate_random_uli()  # Replace the existing ULI with random number
                
                writer.writerow(row)

            except ValueError as e:
                print(f"Error processing row: {row}. Error: {e}")
                writer.writerow(row) #write back the row as is
            except Exception as e:
                 print(f"General error processing row: {row}. Error: {e}")
                 writer.writerow(row)


if __name__ == "__main__":
    input_csv_file = "conndr_input_sorted.csv"
    output_csv_file = "conndr_input_sorted_uli.csv"
    
    # Define the ULI mapping from the OCR provided
    uli_mapping = {
        "22:00": "283", "22:05": "283", "22:10": "283", "22:15": "283", "22:20": "283", "22:25": "283", "22:30": "283",
        "22:35": "283", "22:40": "283", "22:45": "283", "22:50": "283", "22:55": "283", "23:00": "283", "23:05": "283",
        "23:10": "283", "23:15": "283", "23:20": "283", "23:25": "283", "23:30": "283", "23:35": "283", "23:40": "283",
        "23:45": "283", "23:50": "283", "23:55": "283", "00:00": "283", "00:05": "283", "00:10": "283", "00:15": "283",
        "00:20": "283", "00:25": "283", "00:30": "283", "00:35": "283", "00:40": "283", "00:45": "283", "00:50": "283",
        "00:55": "283", "01:00": "283", "01:05": "283", "01:10": "283", "01:15": "283", "01:20": "283", "01:25": "283",
        "01:30": "283", "01:35": "283", "01:40": "283", "01:45": "283", "01:50": "283", "01:55": "283", "02:00": "283",
        "02:05": "283", "02:10": "283", "02:15": "283", "02:20": "283", "02:25": "283", "02:30": "283", "02:35": "283",
        "02:40": "283", "02:45": "283", "02:50": "283", "02:55": "283", "03:00": "283", "03:05": "283", "03:10": "283",
        "03:15": "283", "03:20": "283", "03:25": "283", "03:30": "283", "03:35": "283", "03:40": "283", "03:45": "283",
        "03:50": "283", "03:55": "283", "04:00": "283", "04:05": "283", "04:10": "283", "04:15": "283", "04:20": "283",
        "04:25": "283", "04:30": "283", "04:35": "283", "04:40": "283", "04:45": "283", "04:50": "283", "04:55": "283",
        "05:00": "283", "05:05": "283", "05:10": "283", "05:15": "283", "05:20": "283", "05:25": "283", "05:30": "283",
        "05:35": "283", "05:40": "283", "05:45": "283", "05:50": "283", "05:55": "283", "06:00": "283", "06:05": "283",
        "06:10": "283", "06:15": "283", "06:20": "283", "06:25": "283", "06:30": "283", "06:35": "283", "06:40": "283",
        "06:45": "283", "06:50": "283", "06:55": "283", "07:00": "283", "07:05": "283", "07:10": "283", "07:15": "283",
        "07:20": "283", "07:25": "283", "07:30": "283", "07:35": "283", "07:40": "283", "07:45": "283", "07:50": "283",
        "07:55": "286", "08:00": "286", "08:05": "285", "08:10": "163", "08:15": "163", "08:20": "163", "08:25": "290",
        "08:30": "167", "08:35": "288", "08:40": "288", "08:45": "45", "08:50": "46", "08:55": "44", "09:00": "44",
        "09:05": "44", "09:10": "44", "09:15": "44", "09:20": "44", "09:25": "44", "09:30": "44", "09:35": "44",
        "09:40": "44", "09:45": "44", "09:50": "44", "09:55": "44", "10:00": "44", "10:05": "44", "10:10": "44",
        "10:15": "71", "10:20": "71", "10:25": "71", "10:30": "72", "10:35": "72", "10:40": "72", "10:45": "72",
        "10:50": "72", "10:55": "72", "11:00": "72", "11:05": "72", "11:10": "71", "11:15": "71", "11:20": "72",
        "11:25": "71", "11:30": "71", "11:35": "44", "11:40": "44", "11:45": "44", "11:50": "44", "11:55": "44",
        "12:00": "44", "12:05": "44", "12:10": "44", "12:15": "44", "12:20": "44", "12:25": "44", "12:30": "44",
        "12:35": "44", "12:40": "44", "12:45": "44", "12:50": "44", "12:55": "44", "13:00": "44", "13:05": "44",
        "13:10": "44", "13:15": "44", "13:20": "44", "13:25": "44", "13:30": "44", "13:35": "44", "13:40": "44",
        "13:45": "46", "13:50": "45", "13:55": "48", "14:00": "51", "14:05": "58", "14:10": "52", "14:15": "52",
        "14:20": "53", "14:25": "53", "14:30": "53", "14:35": "53", "14:40": "53", "14:45": "53", "14:50": "53",
        "14:55": "53", "15:00": "53", "15:05": "53", "15:10": "53", "15:15": "58", "15:20": "52", "15:25": "49",
        "15:30": "55", "15:35": "73", "15:40": "287", "15:45": "77", "15:50": "77", "15:55": "77", "16:00": "162",
        "16:05": "162", "16:10": "81",  "16:15": "283", "16:20": "283", "16:25": "283", "16:30": "283", "16:35": "283",
        "16:40": "283", "16:45": "283", "16:50": "283", "16:55": "283", "17:00": "283", "17:05": "283", "17:10": "283",
        "17:15": "283", "17:20": "283", "17:25": "283", "17:30": "283", "17:35": "283", "17:40": "283", "17:45": "283",
        "17:50": "283", "17:55": "283", "18:00": "283", "18:05": "283", "18:10": "283", "18:15": "283", "18:20": "283",
        "18:25": "283", "18:30": "283", "18:35": "283", "18:40": "283", "18:45": "283", "18:50": "282", "18:55": "281",
        "19:00": "281", "19:05": "276", "19:10": "278", "19:15": "273", "19:20": "274", "19:25": "265", "19:30": "102",
        "19:35": "103", "19:40": "101", "19:45": "101", "19:50": "101", "19:55": "101", "20:00": "102", "20:05": "101",
        "20:10": "101", "20:15": "84",  "20:20": "85",  "20:25": "87",  "20:30": "83",  "20:35": "86",  "20:40": "203",
        "20:45": "38",  "20:50": "38",  "20:55": "38",  "21:00": "38",  "21:05": "38",  "21:10": "38",  "21:15": "38",
        "21:20": "38",  "21:25": "38",  "21:30": "39",  "21:35": "40",  "21:40": "104", "21:45": "41", "21:50": "42", "21:55": "283"
    }

    process_csv(input_csv_file, output_csv_file, uli_mapping)
    print(f"Processed data written to {output_csv_file}")