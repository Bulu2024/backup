#!/usr/bin/env python3.6
import os
import logging
from datetime import datetime, timedelta
import hashlib
from dotenv import load_dotenv
from clickhouse_driver import Client
import pandas as pd
from langchain.chat_models import ChatOpenAI
from langchain.prompts import ChatPromptTemplate
from langchain.output_parsers import StructuredOutputParser, ResponseSchema

DEFAULT_ENV_PATH = os.getenv('ENV_PATH')
if os.path.exists(DEFAULT_ENV_PATH):
    load_dotenv(dotenv_path=DEFAULT_ENV_PATH)
else:
    print(f"ERROR: No env file found at {ENV_PATH} or {DEFAULT_ENV_PATH}!")
    exit()

# Configuration from environment variables
LOG_FILE = os.getenv('LOG_FILE')
DB_IP = os.getenv('DB_IP')
DB_USER = os.getenv('DB_USER')
DB_PASSWORD = os.getenv('DB_PASSWORD')
DB_NAME = os.getenv('DB_NAME')
OPENAI_API_KEY = os.getenv('OPENAI_API_KEY')

# Logging configuration
JOB_NAME = "MAKE CONNECTIONS"
logging.basicConfig(filename=LOG_FILE, level=logging.INFO,
                    format='%(asctime)s.%(msecs)03d [' + JOB_NAME + '] %(message)s',
                    datefmt='%Y-%m-%d %H:%M:%S')

def get_clickhouse_client():
    """Establishes a connection to ClickHouse using environment variables."""
    client = Client(
        host=DB_IP,
        user=DB_USER,
        password=DB_PASSWORD,
        database=DB_NAME)
    client.execute("SELECT 1")
    logging.debug("Successfully connected to ClickHouse")
    return client

# Set up OpenAI connection
os.environ["OPENAI_API_KEY"] = OPENAI_API_KEY
llm = ChatOpenAI(model="gpt-3.5-turbo")

# Define the response schema for the LLM
response_schemas = [
    ResponseSchema(name="insight", description="The main insight from the data"),
    ResponseSchema(name="query_used", description="The SQL query that was used to generate the insight")
    ]
output_parser = StructuredOutputParser.from_response_schemas(response_schemas)
format_instructions = output_parser.get_format_instructions()

# Define prompts
template = """
    Your job is to act as an expert data analyst. I will provide you with the schema of a SQL table, then I will ask you to provide insights
    based on that schema. It is very important that you return the SQL query you used and the insight in the format specified at the end.
    
    Here is the schema for the table `fact_rt`:
    
    {schema}

    Here is the user question:
    Which user used most Uber?
    
    {format_instructions}
"""
prompt = ChatPromptTemplate.from_template(template)


def get_clickhouse_schema(client, table_name):
    query = f"DESCRIBE TABLE {table_name}"
    response = client.execute(query)
    
    schema_str = ""
    for row in response:
        schema_str += f"Column: {row[0]}, Type: {row[1]}\n"
    return schema_str

def get_insights_from_question(client, user_question):
    
    schema = get_clickhouse_schema(client, "fact_rt")
    messages = prompt.format_messages(schema=schema, user_question=user_question, format_instructions=format_instructions)

    response = llm(messages)
    
    try:
        output_dict = output_parser.parse(response.content)
    except Exception as e:
        logging.error(f"Error parsing response: {e}")
        return None
        
    query = output_dict.get("query_used")
    insight = output_dict.get("insight")
    
    logging.info(f"Query Used: {query}")
    logging.info(f"Insight: {insight}")

    if query:
        try:
           result = client.execute(query)
           df = pd.DataFrame(result)
        except Exception as e:
            logging.error(f"Error running query: {e}")
            return None
    else:
        return None
    
    return df

if __name__ == '__main__':
    
    clickhouse_client = get_clickhouse_client()
    
    user_questions = [
        "What app is mostly used in the morning?",
        "What is the top subscriber that uses the Tinder App?",
        "How much volume is passing through the 'Mobile-Site2_SG9700' SG?"
        ]

    for user_question in user_questions:
        logging.info(f"User question: {user_question}")
        df = get_insights_from_question(clickhouse_client, user_question)

        if df is not None:
            logging.info(f"Result DataFrame: \n{df}")
        logging.info("-" * 80)
