#!/bin/bash

# Load environment variables
if [ -z "$ENV_PATH" ]; then
  echo "Error: ENV_PATH environment variable is not set."
  exit 1
fi

source "$ENV_PATH"

# Check if the table name argument is provided
if [ -z "$1" ]; then
  echo "Usage: $0 <table_name>"
  exit 1
fi

TABLE_NAME="$1"
JOB="[TABLE_COPY]"

# Ensure the log file exists
touch "$LOG_FILE"
chmod 666 "$LOG_FILE"

echo "$(date "+%Y-%m-%d %H:%M:%S.%3N") $JOB Starting copy for table '$TABLE_NAME'" >> "$LOG_FILE"

# Construct the connection strings for each DWH node
DWH1_CONN="clickhouse-client --host $DWH1 --user $DB_USER --password $DB_PASSWORD --database $DB_NAME"
DWH2_CONN="clickhouse-client --host $DWH2 --user $DB_USER --password $DB_PASSWORD --database $DB_NAME"
DWH3_CONN="clickhouse-client --host $DWH3 --user $DB_USER --password $DB_PASSWORD --database $DB_NAME"

# 1. Export data from DWH1
echo "$(date "+%Y-%m-%d %H:%M:%S.%3N") $JOB Exporting data from DWH1 for table '$TABLE_NAME' " >> "$LOG_FILE"
DATA=$($DWH1_CONN --query "SELECT * FROM $TABLE_NAME FORMAT CSV")

if [ $? -ne 0 ]; then
  echo "$(date "+%Y-%m-%d %H:%M:%S.%3N") $JOB ERROR: Failed to export data from DWH1. Check ClickHouse logs." >> "$LOG_FILE"
  exit 1
fi


# 2. Insert data into DWH2
echo "$(date "+%Y-%m-%d %H:%M:%S.%3N") $JOB Inserting data into DWH2 for table '$TABLE_NAME'" >> "$LOG_FILE"
echo "$DATA" | $DWH2_CONN --query "INSERT INTO $TABLE_NAME FORMAT CSV"
if [ $? -ne 0 ]; then
  echo "$(date "+%Y-%m-%d %H:%M:%S.%3N") $JOB ERROR: Failed to insert data into DWH2. Check ClickHouse logs." >> "$LOG_FILE"
  exit 1
fi

# 3. Insert data into DWH3
echo "$(date "+%Y-%m-%d %H:%M:%S.%3N") $JOB Inserting data into DWH3 for table '$TABLE_NAME'" >> "$LOG_FILE"
echo "$DATA" | $DWH3_CONN --query "INSERT INTO $TABLE_NAME FORMAT CSV"
if [ $? -ne 0 ]; then
   echo "$(date "+%Y-%m-%d %H:%M:%S.%3N") $JOB ERROR: Failed to insert data into DWH3. Check ClickHouse logs." >> "$LOG_FILE"
  exit 1
fi


# 4. Optimize final on all nodes for ReplacingMergeTree
echo "$(date "+%Y-%m-%d %H:%M:%S.%3N") $JOB Running OPTIMIZE FINAL on all nodes for table '$TABLE_NAME'" >> "$LOG_FILE"
$DWH1_CONN --query "OPTIMIZE TABLE $TABLE_NAME FINAL"
$DWH2_CONN --query "OPTIMIZE TABLE $TABLE_NAME FINAL"
$DWH3_CONN --query "OPTIMIZE TABLE $TABLE_NAME FINAL"

echo "$(date "+%Y-%m-%d %H:%M:%S.%3N") $JOB Completed data copy and optimize for table '$TABLE_NAME'" >> "$LOG_FILE"

exit 0
