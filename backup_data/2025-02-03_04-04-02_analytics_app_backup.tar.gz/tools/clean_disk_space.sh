#!/bin/bash

echo > /var/log/clickhouse-server/clickhouse-server.log
echo > /var/log/clickhouse-server/clickhouse-server.err.log
echo > /var/log/messages
echo > /var/log/secure
echo > /var/log/cron
echo > /var/log/sudo.log
sudo rm /var/log/sudo-* -f
sudo rm /var/crash/* -f
sudo rm /var/log/audit/audit.log.* -f
sudo journalctl --vacuum-time=1d
ls -t /var/log/sa | tail -n +3 | xargs -I {} rm -f /var/log/sa/{}
