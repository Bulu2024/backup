#!/usr/bin/env python3.6

import requests
import json
import os
from dotenv import load_dotenv

DEFAULT_ENV_PATH = os.getenv('ENV_PATH')
if os.path.exists(DEFAULT_ENV_PATH):
    load_dotenv(dotenv_path=DEFAULT_ENV_PATH)
else:
    print(f"ERROR: No env file found at {ENV_PATH} or {DEFAULT_ENV_PATH}!")
    exit()

GOOGLE_API_KEY = os.getenv('GOOGLE_API_KEY')

def generate_text_gemini(prompt):
    url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent"
    headers = {
        "Content-Type": "application/json",
    }
    params = {
        "key": GOOGLE_API_KEY
    }
    data = {
      "contents": [{
        "parts":[{
            "text": prompt
        }]
      }]
    }
    response = requests.post(url, headers=headers, params=params, data=json.dumps(data))
    response.raise_for_status()
    response_data = response.json()
            
    try:
       text_output = response_data['candidates'][0]['content']['parts'][0]['text']
    except Exception as e:
       print(f"Error getting output: {e}")
       text_output = ""
            
    return text_output


# Example usage
prompt_text = "how much is two plus 4"
generated_text = generate_text_gemini(prompt_text)
print(generated_text)