#!/bin/bash

curl https://www.cidr-report.org/as2.0/autnums.html > asn_list_org.csv

echo "asn_number,asn_name,country_code" > asn_list.csv
while IFS= read -r line; do
    asn_number=$(echo "$line" | grep -o 'AS[0-9]\+' | grep -o '[0-9]\+' | head -1)
    asn_name=$(echo "$line" | sed 's/.*<\/a> \(.*\)/\1/')
    asn_name=${asn_name:0:-3}
    asn_name=$(echo "$asn_name" | tr -d ',')
    country_code=${line: -2}
    echo "$asn_number,$asn_name,$country_code" >> asn_list.csv
done < asn_list_org.csv
