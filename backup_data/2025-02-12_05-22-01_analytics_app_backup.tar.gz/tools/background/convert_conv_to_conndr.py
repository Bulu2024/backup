#!/usr/bin/env python3
import csv
import random
from datetime import datetime, timedelta

def process_traffic_data(input_csv_path, output_csv_path):
    """
    Processes traffic data from an input CSV file, transforms it, and writes it to a new CSV file.

    Args:
        input_csv_path (str): The path to the input CSV file.
        output_csv_path (str): The path to the output CSV file.
    """
    new_headers = [
        "subscriber_key",
        "start_time",
        "end_time",
        "int_ipv4",
        "ext_ipv4",
        "app_key",
        "uli",
        "request_host",
        "volume_in",
        "volume_out",
        "allot_subscriber",
        "conndr_record_type",
        "IMEITAC",
        "IMSI",
        "IMEISV",
        "sg_name",
        "int_port",
        "ext_port",
        "l5_protocol",
        "request_uri",
        "packets_in",
        "packets_out",
        "IMSI_MCC_MNC",
    ]

    with open(input_csv_path, 'r') as infile, open(output_csv_path, 'w', newline='') as outfile:
        reader = csv.reader(infile)
        writer = csv.writer(outfile)

        writer.writerow(new_headers)  # Write the new headers to the output file
        next(reader) # skip the original header
        
        for row in reader:
            # Extract data from original CSV
            subscriber_key = row[9]
            period_min_key = row[12]
            period_end_key = row[32]
            host_internal_key = row[4]
            host_external_key = row[5]
            application_key = row[0]
            network_cell_key = row[10]
            volume_in = row[27]
            volume_out = row[28]
            enforcer_id = row[23]
            network_protocol_type_key = row[3]
            packets_in = row[58]
            packets_out= row[59]
            
            # Convert start time
            start_time_dt = datetime.strptime(period_min_key, '%Y-%m-%d %H:%M:%S')
            random_seconds_start = random.randint(0, 300)
            new_start_time = start_time_dt + timedelta(seconds=random_seconds_start)
            formatted_start_time = new_start_time.strftime('%Y-%m-%d %H:%M:%S')

            # Generate end time
            random_seconds_end = random.randint(0, 120)
            new_end_time = new_start_time + timedelta(seconds=random_seconds_end)
            formatted_end_time = new_end_time.strftime('%Y-%m-%d %H:%M:%S')
            
            # Write to new CSV file
            new_row = [
                subscriber_key,
                formatted_start_time,
                formatted_end_time,
                host_internal_key,
                '', # host_external_key
                application_key,
                network_cell_key,
                '', # request_host
                volume_in,
                volume_out,
                '',  # allot_subscriber
                '',  # conndr_record_type
                '',  # IMEITAC
                '',  # IMSI
                '',  # IMEISV
                enforcer_id, # sg_name
                '', # int_port
                '', # ext_port
                network_protocol_type_key,  # l5_protocol
                '', # request_uri
                packets_in,
                packets_out,
                '', # IMSI_MCC_MNC
            ]
            
            writer.writerow(new_row)
            
if __name__ == "__main__":
    input_csv_file = "conv_raw_20250104.csv"
    output_csv_file = "conndr_input_large.csv"
    process_traffic_data(input_csv_file, output_csv_file)
    print(f"Successfully transformed data from '{input_csv_file}' to '{output_csv_file}'")