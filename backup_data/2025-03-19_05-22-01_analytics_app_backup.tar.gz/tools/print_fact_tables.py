#!/usr/bin/env python3.6
import os
import re
from dotenv import load_dotenv
from clickhouse_driver import Client

DEFAULT_ENV_PATH = os.getenv('ENV_PATH')
if os.path.exists(DEFAULT_ENV_PATH):
    load_dotenv(dotenv_path=DEFAULT_ENV_PATH)
else:
    print(f"ERROR: No env file found at {DEFAULT_ENV_PATH}!")
    exit()

DB_IP = os.getenv('DB_IP')
DB_USER = os.getenv('DB_USER')
DB_PASSWORD = os.getenv('DB_PASSWORD')
DB_NAME = os.getenv('DB_NAME')

def get_clickhouse_client():
    client = Client(
        host=DB_IP,
        user=DB_USER,
        password=DB_PASSWORD,
        database=DB_NAME
    )
    client.execute("SELECT 1")
    return client

client = get_clickhouse_client()

# Get all tables matching fact_%
tables = client.execute("""
    SELECT name FROM system.tables
    WHERE database = currentDatabase() AND name LIKE 'fact_%'
""")

results = []

for (table_name,) in tables:
    # Run SHOW CREATE TABLE to get full DDL
    create_query = client.execute("SHOW CREATE TABLE {}".format(table_name))[0][0]
    
    # Extract the PARTITION BY clause from the DDL.
    m = re.search(r"PARTITION BY\s+([^\n]+)", create_query)
    partition_by = m.group(1).strip() if m else "N/A"
    
    # Get record count from system.parts (summing rows in active parts)
    rec = client.execute("""
        SELECT sum(rows) FROM system.parts
        WHERE database = currentDatabase() AND table = %(table)s AND active = 1
    """, {"table": table_name})
    records = rec[0][0] if rec[0][0] is not None else 0
    
    results.append((table_name, partition_by, records))

# Sort results by the number of records in descending order
results.sort(key=lambda x: x[2], reverse=True)

# Print header
print("{:<35} {:<50} {:>15}".format("Table Name", "Partition By", "Records"))
print("-" * 105)

# Print sorted rows
for table_name, partition_by, records in results:
    print("{:<35} {:<50} {:>15}".format(table_name, partition_by, records))

