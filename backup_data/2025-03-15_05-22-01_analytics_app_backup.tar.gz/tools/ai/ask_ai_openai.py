#!/usr/bin/env python3.6
import os
import requests
import json
import logging
from dotenv import load_dotenv
from clickhouse_driver import Client
from datetime import datetime, timedelta
import sys  # Import the sys module

DEFAULT_ENV_PATH = os.getenv('ENV_PATH')
if os.path.exists(DEFAULT_ENV_PATH):
    load_dotenv(dotenv_path=DEFAULT_ENV_PATH)
else:
    print(f"ERROR: No env file found at {ENV_PATH} or {DEFAULT_ENV_PATH}!")
    exit()

OPENAI_API_KEY = os.getenv('OPENAI_API_KEY')
MY_ENV = os.getenv('MY_ENV')
DB_IP = os.getenv('DB_IP')
DB_USER = os.getenv('DB_USER')
DB_PASSWORD = os.getenv('DB_PASSWORD')
DB_NAME = os.getenv('DB_NAME')
MAIN_DIR = os.getenv('MAIN_DIR')
LOG_FILE = os.path.join(MAIN_DIR, 'tools/ai/main.log')
JOB_NAME = "OPENAI"

logging.basicConfig(filename=LOG_FILE, level=logging.INFO,
                    format='%(message)s')

def generate_text_openai(prompt):
    url = "https://api.openai.com/v1/chat/completions"
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {OPENAI_API_KEY}"
    }
    data = {
#    "model": "ft:gpt-4o-2024-08-06:lonalytics::ApSaPXlo",
    "model": "gpt-4o",
    "messages": [
        {"role": "system", "content": ""},
        {"role": "user", "content": prompt}
    ]
}


    try:
        response = requests.post(url, headers=headers, data=json.dumps(data))
        response.raise_for_status()  # Raise an exception for bad status codes (4xx or 5xx)
        response_data = response.json()
        text_output = response_data['choices'][0]['message']['content'].strip()
    except requests.exceptions.RequestException as e:
        logging.error(f"Error with OpenAI API request: {e}")
        text_output = ""
    except KeyError as e:
        logging.error(f"Error parsing OpenAI API response: {e}")
        text_output = ""
    
    return text_output


def get_clickhouse_client():
    """Establishes a connection to ClickHouse using environment variables."""
    client = Client(
        host=DB_IP,
        user=DB_USER,
        password=DB_PASSWORD,
        database=DB_NAME) #Include DB_NAME to the connection
    client.execute("SELECT 1")
    logging.debug("Successfully connected to ClickHouse")
    return client


def execute_clickhouse_query(sql_query):
    """Executes a SQL query against ClickHouse and returns the results."""
    client = get_clickhouse_client()
    try:
        results = client.execute(sql_query)
        logging.debug(f"SQL Query Executed Successfully: {sql_query}")
        # print(f"DEBUG: ClickHouse query results: {results}")  # Debug print
        return results
    except Exception as e:
        logging.error(f"Error executing ClickHouse query: {e}")
        return None


def format_clickhouse_results(results):
    """Formats ClickHouse results into a string."""
    if not results:
        print("DEBUG: No results to format.") # Debug print
        return "No results found."
    formatted_output = ""
    for row in results:
        formatted_output += str(row) + "\n"
    # print(f"DEBUG: Formatted output: {formatted_output}") # Debug print
    return formatted_output


def generate_sql_query(ai_instructions, user_question):
    """Generates SQL query using OpenAI"""

       #First learn about my DB:
       #{ai_instructions}

    prompt = f"""
        General instructions, DB format, tables name, examples for queries. The question is in the end after the =========:
        {ai_instructions}
        
        =========

        Finally, here is the QUESTION YOU NEED TO ANSWER:
        {user_question}
        When generating a query output only the query, no ```sql, no explanations
    """

    sql_query = generate_text_openai(prompt)
    
    
    
    # print(f"==SQL QUERY:\n{sql_query}")  # Debug print

    logging.info(f"===========\nSQL QUERY:\n{sql_query}")

    if sql_query.lower().startswith("error"):
         return None
    else:
         return sql_query

def generate_answer(formatted_output, user_question):
   """Generates an answer to the user question using the DB results"""
   prompt = f"""
        This was the original question:
        {user_question}
        
        Here are the results from the SQL query:
        {formatted_output}

        generate a human friendly answer. Include few details in the answer (e.g. results from the query). You should answer in a table format whenever possible. Shortly explain your conclusions and how you reached the answer.
    """
   answer = generate_text_openai(prompt)

   logging.info(f"===========\nRAW ANSWER:\n{formatted_output}")
   logging.info(f"===========\nFORMATTED ANSWER:\n{answer}")
   return answer


if __name__ == "__main__":

    # Get the user question from the command line arguments
    if len(sys.argv) > 1:
        user_question = sys.argv[1].strip("[]").strip("'\"")
    else:
        print("Error: Please provide a user question as a command-line argument.")
        sys.exit(1)
    
    if not user_question or user_question in ["''", '""', "[]", "{}", "select..."]:
        sys.exit(1)
        
    instruction_files = {
    'CLUSTER': f'{MAIN_DIR}/tools/ai/ai_instructions_cluster.txt',
    'STANDALONE': f'{MAIN_DIR}/tools/ai/ai_instructions_standalone.txt'
    }
    INSTRUCTION_FILE = instruction_files.get(MY_ENV, f'{MAIN_DIR}/tools/ai/ai_instructions.txt')

    with open(INSTRUCTION_FILE, 'r') as file:
        ai_instructions = file.read()
    
    logging.debug(f"===========\nINSTRUCTIONS FILE: {INSTRUCTION_FILE}\n{ai_instructions}")
    logging.info(f"===========\nQUESTION:\n{user_question}")


    sql_query = generate_sql_query(ai_instructions, user_question)

    if sql_query:
       results = execute_clickhouse_query(sql_query)
       formatted_output = format_clickhouse_results(results)
       answer = generate_answer(formatted_output, user_question)
       print(f"{answer}")
    else:
       print("Error: Could not generate SQL query, please check the logs for more details.")
