#!/usr/bin/env python3

import os
import gzip
from datetime import datetime, timedelta
import time

SRC_DIR = "/analytics/conndr_input/1_received"
DST_DIR = "/analytics/conndr_input/2_modified"
DONE_DIR = "/analytics/conndr_input/3_done"
LOG_FILE = "/analytics/main.log"
JOB = "[BUCKETS_MODIFIER]"

HEADER = ",".join([
    "subscriber_key", "start_time", "end_time", "int_ipv4", "ext_ipv4", "app_key",
    "uli", "request_host", "volume_in", "volume_out", "allot_subscriber",
    "conndr_record_type", "IMEITAC", "IMSI", "IMEISV", "sg_name", "int_port",
    "ext_port", "l5_protocol", "request_uri", "packets_in", "packets_out", "IMSI_MCC_MNC"
])

local_offset_hours = -time.timezone // 3600 if not time.localtime().tm_isdst else -time.altzone // 3600
local_offset = timedelta(hours=local_offset_hours)


def log(message):
    now = datetime.now()
    with open(LOG_FILE, "a") as log_file:
        log_file.write(f"{now:%Y-%m-%d %H:%M:%S.%f}"[:-3] + f" {JOB} {message}\n")


def transform_datetime(dt_str):
    dt_str = dt_str.strip().replace(" GMT", "").strip('"')  # Remove quotes and GMT suffix
    dt = datetime.strptime(dt_str, "%Y-%m-%d %H:%M:%S %z")  # Parse datetime with timezone
    local_dt = dt + local_offset  # Adjust to local timezone
    return f"{local_dt:%Y-%m-%d %H:%M:%S}"


def process_file(file_path):
    file_name = os.path.basename(file_path)
    log(f"Start {file_name}")
    record_count = 0
    buffer = []  # Buffer for batch writing

    output_file = os.path.join(DST_DIR, f"{file_name[:-7]}.modified.csv.gz")

    with gzip.open(file_path, "rt") as gz_in, gzip.open(output_file, "wt", compresslevel=0) as gz_out:
        gz_out.write(HEADER + "\n")  # Write header

        for line_num, line in enumerate(gz_in):
            if line_num == 0:  # Skip the input header
                continue

            fields = line.strip().split(",")
            try:
                fields[1] = transform_datetime(fields[1])
                fields[2] = transform_datetime(fields[2])
                row = ",".join(fields).replace('"', "")  # Prepare the row
                buffer.append(row)

                # Write in batches of 10,000 rows to minimize I/O
                if len(buffer) >= 10000:
                    gz_out.write("\n".join(buffer) + "\n")
                    buffer.clear()
                record_count += 1
            except Exception:
                continue

        # Write any remaining rows in the buffer
        if buffer:
            gz_out.write("\n".join(buffer) + "\n")

    os.rename(file_path, os.path.join(DONE_DIR, file_name))
    log(f"Processed {record_count} records {file_name}")


def main():
    for file in os.listdir(SRC_DIR):
        if file.endswith(".csv.gz"):
            process_file(os.path.join(SRC_DIR, file))

if __name__ == "__main__":
    main()
