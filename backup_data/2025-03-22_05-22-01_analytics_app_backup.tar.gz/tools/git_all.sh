#!/bin/bash

# Load environment variables
source "$ENV_PATH"
cd "$MAIN_DIR" || { echo "Failed to change directory to $MAIN_DIR"; exit 1; }

git add .
git commit -a
git push -u origin main 

ssh root@3.1.1.2 "cd /opt/analytics/ && git pull --no-edit"
ssh root@3.1.1.3 "cd /opt/analytics/ && git pull --no-edit"

