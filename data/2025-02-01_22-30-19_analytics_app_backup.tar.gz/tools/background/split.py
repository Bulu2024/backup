#!/usr/bin/env python3
import csv
from datetime import datetime, timedelta

def split_large_csv(input_csv_path, output_base_path):
    """
    Splits a large CSV file into multiple CSV files based on 5-minute intervals
    of the start_time, where the file name corresponds to the end of the interval.

    Args:
        input_csv_path (str): The path to the input CSV file.
        output_base_path (str): The base path for output CSV files (e.g., "conndr_input").
    """

    output_files = {}  # Dictionary to store file objects for each interval
    
    with open(input_csv_path, 'r', newline='') as infile:
        reader = csv.reader(infile)
        header = next(reader)  # Read the header row
        
        for row in reader:
             # Extract start_time
            start_time_str = row[1]
            start_time_dt = datetime.strptime(start_time_str, '%Y-%m-%d %H:%M:%S')
            
            # Extract end_time
            end_time_str = row[2]
            end_time_dt = datetime.strptime(end_time_str, '%Y-%m-%d %H:%M:%S')

            # Determine the 5-minute interval end
            minute_end = (start_time_dt.minute // 5 * 5) + 5
            
            if minute_end >= 60:
                interval_end = start_time_dt.replace(minute=0, second=0, microsecond=0) + timedelta(hours=1)
            else:
                interval_end = start_time_dt.replace(minute=minute_end, second=0, microsecond=0)

            # Create a filename base on time
            file_time = interval_end.strftime("%H:%M:%S")
            output_file_name = f"{output_base_path}_5min_{file_time}.csv"

            if output_file_name not in output_files:
                output_files[output_file_name] = open(output_file_name, 'w', newline='')
                writer = csv.writer(output_files[output_file_name])
                writer.writerow(header)  # Write header to new file
            else:
                writer = csv.writer(output_files[output_file_name])
            
            # Modify start_time date to YYYY-MM-DD, keep the original time
            time_part = start_time_dt.strftime('%H:%M:%S')
            row[1] = f"YYYY-MM-DD {time_part}"
            
            # Modify end_time date to YYYY-MM-DD, keep the original time
            time_part = end_time_dt.strftime('%H:%M:%S')
            row[2] = f"YYYY-MM-DD {time_part}"

            writer.writerow(row) # Write data row
            
    # Close all output files
    for file in output_files.values():
        file.close()

    print("Successfully split the large CSV into multiple files based on time intervals.")


if __name__ == "__main__":
    input_csv_file = "conndr_input_sorted_uli.csv"
    output_base_path = "conndr_input"
    split_large_csv(input_csv_file, output_base_path)