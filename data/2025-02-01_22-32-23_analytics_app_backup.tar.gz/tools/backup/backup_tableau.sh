DATE=$(date +%Y%m%d)
sudo tar -czvf file_store_backup_${DATE}.tar.gz /var/opt/tableau/tableau_server/data/tabsvc/files/extracts /var/opt/tableau/tableau_server/data/tabsvc/files/datasources /var/opt/tableau/tableau_server/data/tabsvc/files/workbooks
